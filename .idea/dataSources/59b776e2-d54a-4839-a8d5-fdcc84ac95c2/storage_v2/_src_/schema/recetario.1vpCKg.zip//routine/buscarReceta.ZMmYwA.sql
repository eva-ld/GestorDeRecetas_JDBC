create
    definer = root@localhost procedure buscarReceta(IN p_nombre varchar(100))
BEGIN
 SELECT id,
 nombre,
 categoria,
 tiempo_preparacion,
 dificultad,
 raciones
 FROM recetas
 WHERE nombre = p_nombre;
END;

